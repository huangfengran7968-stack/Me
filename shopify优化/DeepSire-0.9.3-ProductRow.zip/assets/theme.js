class DeepSireTheme {
  constructor() {
    this.bindMenu();
    this.bindProductCards();
    this.bindProductForms();
    this.bindProductGalleries();
    this.bindQuantity();
    this.bindAgeGate();
    this.bindCreatorVideos();
    this.bindCartDrawer();
    this.bindFilters();
    this.bindAccountRecovery();
  }

  bindMenu() {
    const toggle = document.querySelector('[data-menu-toggle]');
    const nav = document.querySelector('[data-primary-nav]');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
      document.body.classList.toggle('menu-open', open);
      if (open) nav.querySelector('a')?.focus();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape' || !nav.classList.contains('is-open')) return;
      nav.classList.remove('is-open');
      document.body.classList.remove('menu-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    });
  }

  bindProductCards() {
    document.querySelectorAll('[data-product-card]').forEach((card) => {
      const image = card.querySelector('[data-card-image]');
      const link = card.querySelector('[data-card-link]');
      card.querySelectorAll('[data-card-swatch]').forEach((swatch) => {
        swatch.addEventListener('click', () => {
          if (swatch.disabled) return;
          card.querySelectorAll('[data-card-swatch]').forEach((item) => item.setAttribute('aria-pressed', 'false'));
          swatch.setAttribute('aria-pressed', 'true');
          if (image && swatch.dataset.image) image.src = swatch.dataset.image;
          if (image && swatch.dataset.srcset) image.srcset = swatch.dataset.srcset;
          if (link && swatch.dataset.url) link.href = swatch.dataset.url;
        });
      });
    });
  }

  bindProductForms() {
    document.querySelectorAll('[data-product-root]').forEach((root) => {
      const variantsNode = root.querySelector('[data-product-variants]');
      const idInput = root.querySelector('[name="id"]');
      const submit = root.querySelector('[data-product-submit]');
      const price = root.querySelector('[data-product-price]');
      const mobileSubmit = root.querySelector('[data-mobile-product-submit]');
      const mobilePrice = root.querySelector('[data-mobile-product-price]');
      if (!variantsNode || !idInput) return;
      let variants;
      try { variants = JSON.parse(variantsNode.textContent); } catch (error) { return; }

      const update = () => {
        const values = [...root.querySelectorAll('[data-option-group]')].map((group) => {
          return group.querySelector('input:checked')?.value;
        });
        const variant = variants.find((item) => item.options.every((option, index) => option === values[index]));
        if (!variant) {
          submit.disabled = true;
          if (mobileSubmit) mobileSubmit.disabled = true;
          return;
        }
        idInput.value = variant.id;
        submit.disabled = !variant.available;
        submit.textContent = variant.available ? submit.dataset.addLabel : submit.dataset.soldLabel;
        if (price) price.innerHTML = variant.price_html;
        if (mobileSubmit) {
          mobileSubmit.disabled = !variant.available;
          mobileSubmit.textContent = variant.available ? mobileSubmit.dataset.addLabel : mobileSubmit.dataset.soldLabel;
        }
        if (mobilePrice) mobilePrice.innerHTML = variant.price_html;
        const url = new URL(window.location.href);
        url.searchParams.set('variant', variant.id);
        window.history.replaceState({}, '', url);
        if (variant.featured_media_id) {
          const target = root.querySelector(`[data-media-id="${variant.featured_media_id}"]`);
          target?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      };
      root.querySelectorAll('[data-option-group] input').forEach((input) => input.addEventListener('change', () => {
        const label = input.closest('[data-option-group]')?.querySelector('[data-selected-value]');
        if (label) label.textContent = input.value;
        update();
      }));
      mobileSubmit?.addEventListener('click', () => {
        root.querySelector('form[action*="/cart/add"]')?.requestSubmit(submit);
      });
    });
  }

  bindProductGalleries() {
    document.querySelectorAll('[data-product-gallery]').forEach((gallery) => {
      const track = gallery.querySelector('[data-gallery-track]');
      const slides = [...gallery.querySelectorAll('[data-gallery-slide]')];
      const dots = [...gallery.querySelectorAll('[data-gallery-dot]')];
      if (!track || slides.length < 2) return;
      const setActive = (index) => dots.forEach((dot, dotIndex) => dot.setAttribute('aria-current', String(dotIndex === index)));
      dots.forEach((dot) => dot.addEventListener('click', () => {
        slides[Number(dot.dataset.galleryDot)]?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
      }));
      let frame;
      track.addEventListener('scroll', () => {
        cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => {
          const index = Math.round(track.scrollLeft / Math.max(track.clientWidth, 1));
          setActive(Math.min(index, slides.length - 1));
        });
      }, { passive: true });
    });
  }

  bindQuantity() {
    document.querySelectorAll('[data-quantity]').forEach((root) => {
      const input = root.querySelector('input');
      root.querySelectorAll('button').forEach((button) => button.addEventListener('click', () => {
        const next = Math.max(1, Number(input.value || 1) + Number(button.dataset.step));
        input.value = next;
      }));
    });
  }

  bindFilters() {
    document.querySelectorAll('[data-filter-form]').forEach((form) => {
      const drawer = form.querySelector('[data-filter-drawer]');
      const open = form.querySelector('[data-filter-open]');
      const close = form.querySelector('[data-filter-close]');
      let returnFocus;
      if (!drawer || !open) return;
      const setOpen = (isOpen) => {
        drawer.classList.toggle('is-open', isOpen);
        document.body.classList.toggle('filter-drawer-open', isOpen);
        open.setAttribute('aria-expanded', String(isOpen));
        if (isOpen) {
          returnFocus = document.activeElement;
          close?.focus();
        } else if (returnFocus instanceof HTMLElement) {
          returnFocus.focus();
        }
      };
      open.addEventListener('click', () => setOpen(true));
      close?.addEventListener('click', () => setOpen(false));
      document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setOpen(false); });
    });
  }

  bindAccountRecovery() {
    const login = document.querySelector('[data-login-panel]');
    const recovery = document.querySelector('[data-recover-panel]');
    if (!login || !recovery) return;
    const showRecovery = (show) => {
      login.hidden = show;
      recovery.hidden = !show;
      (show ? recovery : login).querySelector('input')?.focus();
    };
    document.querySelector('[data-recover-open]')?.addEventListener('click', (event) => { event.preventDefault(); showRecovery(true); });
    document.querySelector('[data-recover-close]')?.addEventListener('click', (event) => { event.preventDefault(); showRecovery(false); });
    if (window.location.hash === '#recover') showRecovery(true);
  }

  bindAgeGate() {
    const gate = document.querySelector('[data-age-gate]');
    if (!gate) return;
    const key = 'deepsire_adult_entry_acknowledged';
    const maxAge = 30 * 24 * 60 * 60 * 1000;
    const storage = {
      get() { try { const value = JSON.parse(localStorage.getItem(key)); return value && Date.now() - value.acknowledgedAt < maxAge ? value : null; } catch (error) { return null; } },
      set() { try { localStorage.setItem(key, JSON.stringify({ acknowledged: true, acknowledgedAt: Date.now(), method: 'self_declaration' })); } catch (error) {} }
    };
    if (storage.get()) {
      document.body.classList.add('age-verified');
      return;
    }
    if (gate.dataset.restricted !== 'true') return;
    const pageRegions = [...document.querySelectorAll('body > header, body > main, body > footer')];
    gate.hidden = false;
    document.body.classList.add('age-gate-open');
    pageRegions.forEach((region) => { region.inert = true; });
    gate.querySelector('[data-age-confirm]')?.focus();
    gate.querySelector('[data-age-confirm]')?.addEventListener('click', () => {
      storage.set();
      gate.hidden = true;
      document.body.classList.remove('age-gate-open');
      document.body.classList.add('age-verified');
      pageRegions.forEach((region) => { region.inert = false; });
    });
    gate.querySelector('[data-age-leave]')?.addEventListener('click', () => {
      window.location.assign(gate.dataset.exitUrl || '/');
    });
    gate.addEventListener('keydown', (event) => {
      if (event.key !== 'Tab') return;
      const controls = [...gate.querySelectorAll('button, a[href]')].filter((item) => !item.disabled);
      if (!controls.length) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  }

  bindCreatorVideos() {
    document.querySelectorAll('[data-creator-video-open]').forEach((trigger) => {
      const dialog = document.getElementById(trigger.dataset.creatorVideoOpen);
      if (!dialog) return;
      const stopMedia = () => {
        dialog.querySelectorAll('video').forEach((video) => video.pause());
        dialog.querySelectorAll('iframe').forEach((frame) => {
          const source = frame.src;
          frame.src = source;
        });
      };
      trigger.addEventListener('click', () => dialog.showModal());
      dialog.querySelector('[data-creator-video-close]')?.addEventListener('click', () => {
        stopMedia();
        dialog.close();
        trigger.focus();
      });
      dialog.addEventListener('click', (event) => {
        if (event.target !== dialog) return;
        stopMedia();
        dialog.close();
        trigger.focus();
      });
      dialog.addEventListener('cancel', stopMedia);
    });
  }

  bindCartDrawer() {
    document.addEventListener('click', (event) => {
      const open = event.target.closest('[data-cart-open]');
      const close = event.target.closest('[data-cart-close]');
      const drawer = document.querySelector('[data-cart-drawer]');
      if (open && drawer) {
        event.preventDefault();
        this.cartReturnFocus = open;
        drawer.showModal();
      }
      if (close && drawer) {
        drawer.close();
        this.cartReturnFocus?.focus();
      }
    });

    document.addEventListener('click', (event) => {
      const drawer = event.target.closest('[data-cart-drawer]');
      if (drawer && event.target === drawer) {
        drawer.close();
        this.cartReturnFocus?.focus();
      }
    });

    document.querySelectorAll('form[action*="/cart/add"]').forEach((form) => {
      form.addEventListener('submit', async (event) => {
        const drawer = document.querySelector('[data-cart-drawer]');
        if (!drawer) return;
        event.preventDefault();
        const submit = form.querySelector('[type="submit"]');
        submit?.setAttribute('aria-busy', 'true');
        try {
          const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart/add.js`, {
            method: 'POST',
            headers: { Accept: 'application/json' },
            body: new FormData(form)
          });
          if (!response.ok) throw new Error('Cart request failed');
          const sectionResponse = await fetch(`${window.Shopify?.routes?.root || '/'}?section_id=cart-drawer`);
          const sectionText = await sectionResponse.text();
          const nextDocument = new DOMParser().parseFromString(sectionText, 'text/html');
          const nextDrawer = nextDocument.querySelector('[data-cart-drawer]');
          if (nextDrawer) drawer.replaceWith(nextDrawer);
          const activeDrawer = document.querySelector('[data-cart-drawer]');
          activeDrawer?.showModal();
          const cartResponse = await fetch(`${window.Shopify?.routes?.root || '/'}cart.js`);
          const cart = await cartResponse.json();
          document.querySelectorAll('.cart-count').forEach((badge) => {
            badge.textContent = cart.item_count;
            badge.hidden = cart.item_count === 0;
          });
        } catch (error) {
          window.location.assign(`${window.Shopify?.routes?.root || '/'}cart`);
        } finally {
          submit?.removeAttribute('aria-busy');
        }
      });
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new DeepSireTheme());
} else {
  new DeepSireTheme();
}

if (!customElements.get('product-recommendations')) {
  customElements.define('product-recommendations', class ProductRecommendations extends HTMLElement {
    connectedCallback() {
      const url = this.dataset.url;
      if (!url) return;
      fetch(url)
        .then((response) => response.text())
        .then((text) => {
          const html = new DOMParser().parseFromString(text, 'text/html');
          const recommendations = html.querySelector('product-recommendations');
          if (recommendations?.innerHTML.trim()) this.innerHTML = recommendations.innerHTML;
        })
        .catch(() => {});
    }
  });
}
